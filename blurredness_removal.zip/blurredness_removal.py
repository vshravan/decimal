# -*- coding: utf-8 -*-
"""
Created on Tue Sep 20 10:56:37 2022

@author: shari
"""
import cv2 as cv
import matplotlib.pyplot as plt

#input

img = cv.imread("D:/HTR1/Autoencoders/sample3.PNG",0)

plt.imshow(img)
#gaussian Blur

img = cv.GaussianBlur(img, (15,15),0)

#adaptive threshold

th3 = cv.adaptiveThreshold(img,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C,cv.THRESH_BINARY,11,2)
plt.imshow(th3)
    
